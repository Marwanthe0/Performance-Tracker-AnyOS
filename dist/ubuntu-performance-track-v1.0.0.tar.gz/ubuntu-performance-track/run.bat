@echo off
REM run.bat - Quick launcher for Performance Track on Windows
setlocal
set "DIR=%~dp0"
set "PYTHONPATH=%DIR%;%PYTHONPATH%"

echo [*] Starting Performance Track...
py -m performance_track.app %* 2>nul || python -m performance_track.app %*
